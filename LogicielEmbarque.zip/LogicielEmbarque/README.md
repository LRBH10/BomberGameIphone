LogicielEmbarquee
=================
                lien outils : 
					Introduction rapide a Objective C : http://www.otierney.net/objective-c.html
					Pour Commencer a programmer sur iphone : http://www.raywenderlich.com/tutorials

					un autre lien http://db-in.com/blog/2011/01/all-about-opengl-es-2-x-part-13/

					IL FAUT PENSEE QUE OPENGL EST DE ECRIT EN C pas en Objective C 
					ALORS TOUTES TUTORIEL EN OpenGL est possible a lire
					pense  a  lire sur les SHADERS et l ex�cution sur GPU :) (Proccessur de la carte graphique) 
	
				
	Remarque : Objective C est un m�lange entre C AINSI et SMALLTALK :)
