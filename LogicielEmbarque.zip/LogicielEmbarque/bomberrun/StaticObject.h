//
//  StaticObject.h
//  CH05_SLQTSOR
//
//  Created by Lion User on 03/01/13.
//
//

#import "AbstractObject.h"

@interface StaticObject : AbstractObject

@end
